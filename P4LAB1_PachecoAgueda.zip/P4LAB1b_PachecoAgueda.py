import turtle


wn = turtle.Screen()
wn.bgcolor("pink")
wn.title("ACP")


t = turtle.Turtle()
t.speed(1)
t.color("blue")


def draw_A(t):
    t.penup()
    t.goto(-100, -50)
    t.pendown()
    t.left(60)
    t.forward(100)
    t.right(120)
    t.forward(100)
    t.backward(50)
    t.right(120)
    t.forward(50)


def draw_P(t):
    t.penup()
    t.goto(50, -50)
    t.pendown()
    t.right(90)
    t.forward(100)
    t.right(90)
    t.circle(-25, 180)
    t.penup()
    t.goto(50, -50)
    t.setheading(0)
    t.pendown()


draw_A(t)
t.penup()
t.goto(0,0)
t.pendown()
draw_P(t)

t.hideturtle()
wn.mainloop()

