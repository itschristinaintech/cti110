import turtle

wn = turtle.Screen()
wn.bgcolor("pink")
wn.title("Square and Triangle")

t = turtle.Turtle()
t.speed(1)

t = turtle.Turtle()
t.color("blue")                       

for i in [0,1,2,3]:
    t.forward(50)
    t.left(90)


for i in [0,1,2,3,4]:
    t.forward(100)
    t.left(120)
 

t.hideturtle()
wn.mainloop()
